///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include <glm/gtx/transform.hpp>
#include <iostream>

// declare the global variables
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
    // free up the allocated memory
    m_pShaderManager = NULL;
    if (NULL != m_basicMeshes)
    {
        delete m_basicMeshes;
        m_basicMeshes = NULL;
    }
    // clear the collection of defined materials
    m_objectMaterials.clear();
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.size() == 0)
    {
        return false;
    }

    int index = 0;
    bool bFound = false;
    while ((index < m_objectMaterials.size()) && (bFound == false))
    {
        if (m_objectMaterials[index].tag.compare(tag) == 0)
        {
            bFound = true;
            material.diffuseColor = m_objectMaterials[index].diffuseColor;
            material.specularColor = m_objectMaterials[index].specularColor;
            material.shininess = m_objectMaterials[index].shininess;
        }
        else
        {
            index++;
        }
    }
    return bFound;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Sets the model matrix using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ,
    glm::vec3 offset)
{
    glm::mat4 modelView;
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ + offset);

    // matrix math is used to calculate the final model matrix
    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (NULL != m_pShaderManager)
    {
        // pass the model matrix into the shader
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Passes the given RGBA color into the shader (without enabling texture).
 ***********************************************************/
void SceneManager::SetShaderColor(
    float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);

    if (NULL != m_pShaderManager)
    {
        // pass the color values into the shader
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Passes the material values into the shader based on the tag.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (m_objectMaterials.size() > 0)
    {
        OBJECT_MATERIAL material;
        bool bReturn = FindMaterial(materialTag, material);
        if (bReturn == true)
        {
            // pass the material properties into the shader
            m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
            m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
            m_pShaderManager->setFloatValue("material.shininess", material.shininess);
        }
    }
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the material settings
 *  for objects in the 3D scene.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    // At least one material must be defined or the lights won't render.

    // Example: A basic "default" material with moderate shininess.
    OBJECT_MATERIAL defaultMaterial;
    defaultMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White base color
    defaultMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);  // Grayish specular
    defaultMaterial.shininess = 16.0f;                        // Moderate shininess
    defaultMaterial.tag = "default";
    m_objectMaterials.push_back(defaultMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene. We add two: a white directional
 *  and a pink point light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    // Turn on custom lighting in the shader.
    // If this is not called, the display will remain unlit (white).
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // 1) Define a WHITE DIRECTIONAL LIGHT (like overhead sunlight).
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -1.0f, -0.3f);
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.1f, 0.1f, 0.1f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.8f, 0.8f, 0.8f);
    m_pShaderManager->setVec3Value("directionalLight.specular", 0.5f, 0.5f, 0.5f);
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);

    // 2) Define a PINK POINT LIGHT to add a pinkish tint.
    //    We'll use pointLights[0].
    m_pShaderManager->setVec3Value("pointLights[0].position", 3.0f, 3.0f, 3.0f);
    // Pinkish color: set ambient to a subtle pink, diffuse to a stronger pink.
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.2f, 0.0f, 0.2f);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 0.0f, 1.0f);
    m_pShaderManager->setVec3Value("pointLights[0].specular", 1.0f, 0.0f, 1.0f);
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

    // Additional point lights can remain inactive if not needed.
    // Just ensure "bActive" is false for them or don't set them at all.
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method prepares the 3D scene by loading shapes,
 *  defining materials, and setting up lighting.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    // Define the materials for objects in the scene
    DefineObjectMaterials();
    // Add and define the light sources for the scene
    SetupSceneLights();

    // Load the basic 3D meshes
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method renders the 3D scene by transforming and
 *  drawing the basic 3D shapes.
 *  We'll apply the same "default" material to each shape.
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    // We'll apply the "default" material to all shapes
    SetShaderMaterial("default");

    // ------------------------------------------------------
    // Plane (base)
    scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    // The actual color is overshadowed by the lighting, but let's pass white anyway.
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawPlaneMesh();

    // ------------------------------------------------------
    // Cylinder
    scaleXYZ = glm::vec3(0.9f, 2.8f, 0.9f);
    XrotationDegrees = 90.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = -15.0f;
    positionXYZ = glm::vec3(0.0f, 0.9f, 0.4f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawCylinderMesh();

    // ------------------------------------------------------
    // Box
    scaleXYZ = glm::vec3(1.0f, 9.0f, 1.3f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 95.0f;
    positionXYZ = glm::vec3(0.2f, 2.27f, 2.0f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawBoxMesh();

    // ------------------------------------------------------
    // Another box
    scaleXYZ = glm::vec3(1.7f, 1.5f, 1.5f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 40.0f;
    ZrotationDegrees = 8.0f;
    positionXYZ = glm::vec3(3.3f, 3.83f, 2.19f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawBoxMesh();

    // ------------------------------------------------------
    // Sphere
    scaleXYZ = glm::vec3(1.0f, 1.0f, 1.0f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 0.0f;
    positionXYZ = glm::vec3(3.1f, 5.6f, 2.5f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawSphereMesh();

    // ------------------------------------------------------
    // Cone
    scaleXYZ = glm::vec3(1.2f, 4.0f, 1.2f);
    XrotationDegrees = 0.0f;
    YrotationDegrees = 0.0f;
    ZrotationDegrees = 5.0f;
    positionXYZ = glm::vec3(-3.3f, 2.48f, 2.0f);
    SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
    SetShaderColor(1, 1, 1, 1);
    m_basicMeshes->DrawConeMesh();
}
