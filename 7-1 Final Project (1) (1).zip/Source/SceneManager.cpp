///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// Manage the preparing and rendering of 3D scenes � textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// Global uniform names.
namespace {
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  Constructor: Initializes the shader manager, mesh loader, and texture storage.
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    for (int i = 0; i < 16; i++) {
        m_textureIDs[i].tag = "";
        m_textureIDs[i].ID = 0;
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  Destructor: Releases allocated resources.
 ***********************************************************/
SceneManager::~SceneManager()
{
    if (m_basicMeshes) {
        delete m_basicMeshes;
        m_basicMeshes = nullptr;
    }
    m_pShaderManager = nullptr;
    DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  Loads a texture from an image file and assigns it a tag.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width, height, colorChannels;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);
    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (image) {
        std::cout << "Successfully loaded image: " << filename
            << ", width: " << width
            << ", height: " << height
            << ", channels: " << colorChannels << std::endl;

        glGenTextures(1, &textureID);
        glBindTexture(GL_TEXTURE_2D, textureID);

        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        if (colorChannels == 3)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        else if (colorChannels == 4)
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        else {
            std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
            stbi_image_free(image);
            return false;
        }

        glGenerateMipmap(GL_TEXTURE_2D);
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);

        m_textureIDs[m_loadedTextures].ID = textureID;
        m_textureIDs[m_loadedTextures].tag = tag;
        m_loadedTextures++;
        return true;
    }
    std::cout << "Could not load image: " << filename << std::endl;
    return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  Binds all loaded textures to their corresponding texture slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++) {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  Frees the memory for all loaded textures.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++) {
        glDeleteTextures(1, &m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  FindTextureID()
 *
 *  Returns the OpenGL texture ID for a given tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    int textureID = -1;
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag) {
            textureID = m_textureIDs[i].ID;
            break;
        }
    }
    return textureID;
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  Returns the texture slot index for a given tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    int slot = -1;
    for (int i = 0; i < m_loadedTextures; i++) {
        if (m_textureIDs[i].tag == tag) {
            slot = i;
            break;
        }
    }
    return slot;
}

/***********************************************************
 *  FindMaterial()
 *
 *  Searches for a material by tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (size_t i = 0; i < m_objectMaterials.size(); i++) {
        if (m_objectMaterials[i].tag == tag) {
            material = m_objectMaterials[i];
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  SetTransformations()
 *
 *  Sets the model matrix using scale, rotation, and translation.
 ***********************************************************/
void SceneManager::SetTransformations(glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ,
    glm::vec3 offset)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ + offset);
    glm::mat4 modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (m_pShaderManager) {
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
    }
}

/***********************************************************
 *  SetShaderColor()
 *
 *  Passes the given RGBA color into the shader (disabling texture).
 ***********************************************************/
void SceneManager::SetShaderColor(float redColorValue,
    float greenColorValue,
    float blueColorValue,
    float alphaValue)
{
    glm::vec4 currentColor(redColorValue, greenColorValue, blueColorValue, alphaValue);
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  Enables texture mapping for the next draw using the given tag.
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager) {
        m_pShaderManager->setIntValue(g_UseTextureName, true);
        int textureSlot = FindTextureSlot(textureTag);
        m_pShaderManager->setSampler2DValue(g_TextureValueName, textureSlot);
    }
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  Passes the UV scale values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager) {
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
    }
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  Passes the material properties into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    OBJECT_MATERIAL material;
    if (FindMaterial(materialTag, material))
    {
        m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", material.shininess);
    }
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Defines a default material for lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    // Default material: white with moderate specular reflection.
    OBJECT_MATERIAL defaultMaterial;
    defaultMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    defaultMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
    defaultMaterial.shininess = 16.0f;
    defaultMaterial.tag = "default";
    m_objectMaterials.push_back(defaultMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Configures a white directional light and a warm point light.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    // Enable custom Phong lighting.
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // WHITE directional light for overall illumination.
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.2f, -1.0f, -0.3f);
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.3f, 0.3f, 0.3f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.8f, 0.8f, 0.8f);
    m_pShaderManager->setVec3Value("directionalLight.specular", 0.5f, 0.5f, 0.5f);
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);

    // WARM point light for soft, warm illumination.
    m_pShaderManager->setVec3Value("pointLights[0].position", 2.0f, 3.0f, 2.0f);
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.3f, 0.2f, 0.0f);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 0.8f, 0.4f);
    m_pShaderManager->setVec3Value("pointLights[0].specular", 1.0f, 0.8f, 0.6f);
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);
}

/***********************************************************
 *  LoadSceneTextures()
 *
 *  Loads textures for the table and background.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    // Table texture (wood)
    CreateGLTexture("textures/wood.jpg", "WOOD");
    // Background texture (brick)
    CreateGLTexture("textures/brick.jpg", "BRICK");

    BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  Prepares the 3D scene: defines materials, sets up lights, loads textures,
 *  and loads the necessary meshes.
 ***********************************************************/
void SceneManager::PrepareScene()
{
    DefineObjectMaterials();
    SetupSceneLights();
    LoadSceneTextures();

    // Load only the meshes needed for this scene:
    // Plane for table & background, Cylinder for cups, Box for handles & book.
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadBoxMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  Renders the scene with:
 *   - A full brick background wall.
 *   - A wooden table.
 *   - Two cups with handles spread apart (one green, one blue).
 *   - An open book on the table with two halves:
 *         � Left half: white pages.
 *         � Right half: green cover/spine.
 ***********************************************************/
void SceneManager::RenderScene()
{
    // Use the default material for lighting calculations.
    SetShaderMaterial("default");

    // 1) BACKGROUND WALL (Brick)
    {
        // Large vertical plane as a wall.
        glm::vec3 scaleXYZ(20.0f, 15.0f, 1.0f);
        float Xrot = 90.0f;  // Upright.
        float Yrot = 0.0f, Zrot = 0.0f;
        glm::vec3 pos(0.0f, 7.5f, -10.0f); // Positioned far back.
        SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
        SetShaderTexture("BRICK");
        m_basicMeshes->DrawPlaneMesh();
    }

    // 2) TABLE (Wood)
    {
        // A larger table surface.
        glm::vec3 scaleXYZ(8.0f, 1.0f, 5.0f);
        float Xrot = -90.0f;
        glm::vec3 pos(0.0f, 0.0f, 0.0f);
        SetTransformations(scaleXYZ, Xrot, 0.0f, 0.0f, pos);
        SetShaderTexture("WOOD");
        m_basicMeshes->DrawPlaneMesh();
    }

    // 3) CUP 1 (Green) - rotated so the handle is visible from the front.
    {
        // Cup body as a cylinder.
        glm::vec3 scaleXYZ(1.0f, 2.0f, 1.0f);  // Bigger cup.
        // Rotate around Y so the cup's front is visible.
        float Xrot = 0.0f, Yrot = -90.0f, Zrot = 0.0f;
        glm::vec3 pos(-3.0f, 2.0f, 1.0f); // Positioned on table, to the left.
        SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
        SetShaderColor(0.0f, 1.0f, 0.0f, 1.0f); // Solid green.
        m_basicMeshes->DrawCylinderMesh();

        // Cup handle as a box.
        scaleXYZ = glm::vec3(0.3f, 1.0f, 0.5f);
        // Place handle on the front side of the cup.
        glm::vec3 posHandle(-2.4f, 2.0f, 1.0f);
        SetTransformations(scaleXYZ, 0.0f, Yrot, 0.0f, posHandle);
        SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f); // Dark gray.
        m_basicMeshes->DrawBoxMesh();
    }

    // 4) CUP 2 (Blue) - rotated similarly.
    {
        // Cup body as a cylinder.
        glm::vec3 scaleXYZ(1.0f, 2.0f, 1.0f);
        float Xrot = 0.0f, Yrot = -90.0f, Zrot = 0.0f;
        glm::vec3 pos(3.0f, 2.0f, 1.0f); // Positioned to the right.
        SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
        SetShaderColor(0.0f, 0.0f, 1.0f, 1.0f); // Solid blue.
        m_basicMeshes->DrawCylinderMesh();

        // Cup handle.
        scaleXYZ = glm::vec3(0.3f, 1.0f, 0.5f);
        glm::vec3 posHandle(3.8f, 2.0f, 1.0f);
        SetTransformations(scaleXYZ, 0.0f, Yrot, 0.0f, posHandle);
        SetShaderColor(0.2f, 0.2f, 0.2f, 1.0f);
        m_basicMeshes->DrawBoxMesh();
    }

    // 5) OPEN BOOK - flat on the table, with two halves:
    //    Left half: white pages, Right half: green cover/spine.
    {
        // Left page (white)
        glm::vec3 scaleXYZ(1.2f, 0.15f, 1.5f);  // Thicker page
        float Xrot = 0.0f, Yrot = 0.0f, Zrot = 0.0f; // Flat on table.
        glm::vec3 pos(-1.0f, 1.0f, 3.0f); // Positioned on the table.
        SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos);
        SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // White pages.
        m_basicMeshes->DrawBoxMesh();

        // Right page (green cover/spine)
        scaleXYZ = glm::vec3(1.2f, 0.15f, 1.5f);
        // Place it to the right of the left page.
        glm::vec3 pos2(1.0f, 1.0f, 3.0f);
        SetTransformations(scaleXYZ, Xrot, Yrot, Zrot, pos2);
        SetShaderColor(0.0f, 0.8f, 0.0f, 1.0f); // Green cover/spine.
        m_basicMeshes->DrawBoxMesh();
    }
}
