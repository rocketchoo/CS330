#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include <glm/glm.hpp>
#include <string>
#include <vector>
#include <cstdint>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including shader settings, textures, materials,
 *  and lighting.
 ***********************************************************/
class SceneManager
{
public:
    // Constructor and destructor
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    // Stores the OpenGL texture info
    struct TEXTURE_INFO
    {
        std::string tag;  // Unique name/identifier
        uint32_t ID;      // OpenGL texture ID
    };

    // Stores material info for lighting calculations
    struct OBJECT_MATERIAL
    {
        glm::vec3 diffuseColor;   // Diffuse color for the material
        glm::vec3 specularColor;  // Specular color for highlights
        float shininess;          // Shininess factor
        std::string tag;          // Material name
    };

public:
    // Main scene preparation and rendering methods
    void PrepareScene();
    void RenderScene();

private:
    // Pointers to core objects
    ShaderManager* m_pShaderManager;  // Manages shader uniforms
    ShapeMeshes* m_basicMeshes;       // Loads/draws basic 3D shapes

    // Textures
    int m_loadedTextures;             // How many textures are loaded
    TEXTURE_INFO m_textureIDs[16];    // Up to 16 texture slots

    // Materials
    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // Texture management
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    int FindTextureID(std::string tag);
    int FindTextureSlot(std::string tag);

    // Material lookup
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Transformation and shader uniform setters
    void SetTransformations(glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ,
        glm::vec3 offset = glm::vec3(0.0f, 0.0f, 0.0f));
    void SetShaderColor(float redColorValue,
        float greenColorValue,
        float blueColorValue,
        float alphaValue);
    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    void SetShaderMaterial(std::string materialTag);

    // Lighting and materials setup
    void DefineObjectMaterials();
    void SetupSceneLights();

    // Loads the textures needed for the scene
    void LoadSceneTextures();
};
